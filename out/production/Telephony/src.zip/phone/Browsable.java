package phone;

public interface Browsable {
    public String browse();
}
