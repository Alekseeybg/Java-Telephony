package phone;

public interface Callable {
    public String call();
}
